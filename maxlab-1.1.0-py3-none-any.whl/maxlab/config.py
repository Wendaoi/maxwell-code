from typing import List

__all__ = ["Config", "electrode_rectangle_indices", "electrode_rectangle_um"]


class Config:
    """
    An object representing a given electrode configuration, along with channel mappings.

    Parameters
    ----------
    str: str
        A string representing the configuration, in the same format saved in ``.cfg`` files.
        The string is in the following format:
        
        ``<channel>(<electrode>)<X>/<Y>;<channel>(<electrode>)<X>/<Y>;...``

        where ``<X>`` and ``<Y>`` represent horizonal and vertical positions on the array, respectively,
        in µm. The position ``<X>=0`` and ``<Y>=0`` represents the top left corner of the array.
        
    Notes
    -----
    The :class:`Config` object representing a configuration routed to an :class:`maxlab.chip.Array`
    can be obtained by calling :func:`mx.Array.get_config()<maxlab.chip.Array.get_config()>`.
    """
    def __init__(self, str: str) -> None:
        config = [
            m.replace("(", " ").replace(")", " ").replace("/", " ").split() for m in str.split()[0].split(";")[:-1]
        ]
        self.mappings = [self.Mapping(*m) for m in config]

    def get_channels(self) -> List[int]:
        """Obtain the channel numbers routed in the configuration.

        Returns
        -------
        List[int]
            A list of channel numbers.
        """
        return [m.channel for m in self.mappings]

    def get_channels_for_electrodes(self, electrodes: List[int]) -> List[int]:
        """Obtain the channel numbers routed to a list of specified electrodes.
        
        Parameters
        ----------
        electrodes: List[int]
            A list of electrode numbers.

        Returns
        -------
        List[int]
            A list of channel numbers routed to the specified electrodes.
        
        """
        return [m.channel for m in self.mappings if m.electrode in electrodes]

    class Mapping:
        def __init__(self, channel: str, electrode: str, x: str, y: str) -> None:
            self.channel = int(channel)
            self.electrode = int(electrode)
            self.x = float(x)
            self.y = float(y)


def electrode_rectangle_indices(xmin: int, ymin: int, xmax: int, ymax: int) -> List[int]:
    return [
        220 * y + x for y in range(max(ymin, 0), min(ymax + 1, 120)) for x in range(max(xmin, 0), min(xmax + 1, 220))
    ]


def electrode_rectangle_um(xmin: float, ymin: float, xmax: float, ymax: float) -> List[int]:
    return electrode_rectangle_indices(int(xmin / 17.5), int(ymin / 17.5), int(xmax / 17.5), int(ymax / 17.5))
