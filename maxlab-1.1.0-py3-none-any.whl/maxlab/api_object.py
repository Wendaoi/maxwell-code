from abc import ABC, abstractmethod


class ApiObject(ABC):
    """Abstract base class for API objects.

    This class serves as a base for implementing API objects that interact
    with external systems or services. Subclasses of `ApiObject` should
    provide their own implementations for the `set` method.

    """

    @abstractmethod
    def set(self) -> str:
        """Set the configuration of the API object.

        When maxlab.send( object derived from ApiObject) is called,
        the set method gets called and it constructs the string that
        is sent to the server.

        """
        pass
