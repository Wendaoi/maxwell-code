#!/usr/bin/python
# -*- coding: utf-8
from . import comm
from . import stream
from .api_object import ApiObject

import math
import time
from collections import defaultdict
from typing import List, Optional, Dict

__all__ = [
    "initialize",
    "activate",
    "offset",
    "hpf",
    "set_gain",
    "get_mean",
    "percentile",
    "group_wells_per_bank",
    "get_no_of_banks",
    "set_primary_well",
    "send",
    "send_raw",
    "error",
    "interrupt_routing",
    "query_DAC_lsb_mV",
    "Timing",
    "clear_events",
    "electrode_neighbors",
    "set_event_threshold",
]


def initialize(wells: Optional[List[int]] = None) -> None:
    """Function to initialize wells to a known state.

    Parameters
    ----------
    wells : List[int], optional
        A list of wells to initialize. If no parameter is passed in, initializes all activated wells.
    """

    with comm.api_context() as api:
        if wells is None:
            api.send("system_initialize")
        else:
            api.send("system_initialize_wells " + ",".join([str(w) for w in wells]))


def activate(wells: List[int]) -> None:
    """Function to select the wells, i.e. in the same fashion as you select wells in
    scope for assays.

    Parameters
    ----------
    wells : List[int]
        A list of wells to activate.

    """
    with comm.api_context() as api:
        api.send("system_set_activated_wells " + ",".join([str(w) for w in wells]))


def offset() -> None:
    """Function to run offset compensation on all activated wells.

    Notes
    -----
    You only need to run an offset compensation command after initialization using the
    :py:func:`mx.initialize()<maxlab.util.initialize()>` command.
    """
    with comm.api_context() as api:
        api.send("system_offset")
        system_type = int(api.send("wellplate_query_version"))
        if system_type == 0:  # MaxOne
            time.sleep(Timing.waitInMX1Offset)
        else:  # MaxTwo
            time.sleep(Timing.waitInMX2Offset)


def hpf(cutoff: str) -> None:
    if cutoff == "1Hz":
        cutoff_value = 4095
    elif cutoff == "300Hz":
        cutoff_value = 1100
    else:
        raise ValueError(
            "Not a valid high-pass parameter: "
            + str(cutoff)
            + "\n"
            + "Allowed values are: '1Hz' and '300Hz'"
        )
    with comm.api_context() as api:
        api.send(f"system_hpf {cutoff_value}")


def set_gain(gain: int) -> None:
    with comm.api_context() as api:
        api.send("system_gain " + str(gain))


def get_mean() -> Dict[int, List[float]]:
    return stream.Stream.get_mean()


def percentile(values: List[float], percent: float) -> Optional[float]:
    """Find the percentile of a list of values.

    Parameters
    ----------
    values : List[float]
        A list of values. Note values MUST BE already sorted.
    percent : float
        A float value from 0.0 to 1.0.

    Returns
    -------
    float
        The percentile of the values.

    """
    if not values:
        return None
    k = (len(values) - 1) * percent
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return values[int(k)]
    d0 = values[int(f)] * (c - k)
    d1 = values[int(c)] * (k - f)
    return d0 + d1


def group_wells_per_bank(wells: List[int]) -> List[List[int]]:
    """Group the given list of wells by banks.

    Parameters
    ----------
    wells : List[int]
        A list of wells. Between 0 and 23

    Returns
    -------
    List[int]
    """
    with comm.api_context() as api:
        mapping = (
            api.send("wellplate_query_well_to_bank_mapping")
            .strip(",")
            .split(
                ",",
            )
        )
        if len(mapping) % 2 != 0:
            return []

        result: Dict[int, List[int]] = defaultdict(list)
        for bank, well in zip(mapping[1::2], mapping[0::2]):
            if int(well) in wells:
                result[int(bank)].append(int(well))
            else:
                continue
        return list(result.values())


def get_no_of_banks(wells: List[int]) -> int:
    """Get the number of banks occupied by the given list of wells.

    Parameters
    ----------
    wells : List[int]
        A list of lists of wells.

    Returns
    -------
    int
    """
    with comm.api_context() as api:
        mapping = (
            api.send("wellplate_query_well_to_bank_mapping")
            .strip(",")
            .split(
                ",",
            )
        )
        if len(mapping) % 2 != 0:
            return -1

        result: Dict[int, List[int]] = defaultdict(list)
        for bank, well in zip(mapping[1::2], mapping[0::2]):
            if int(well) in wells:
                result[int(bank)].append(int(well))
            else:
                continue
        return len(result.keys())


def set_primary_well(well: int) -> None:
    """Select the (single) well from which real-time data should be streamed.

    Parameters
    ----------
    well : int
    """
    with comm.api_context() as api:
        api.send("system_set_primary_well " + str(well))


def send(obj: ApiObject) -> str:
    """Utility function to send command objects to the server API.

    Parameters
    ----------
    obj : ApiObject
        Any object derived from classes in ``maxlab.system`` or ``maxlab.chip``.
        The command object needs a method called :meth:`send()`, which contains
        all the information needed to program the API

    Returns
    -------
    str

    """
    assert isinstance(obj, ApiObject)

    with comm.api_context() as api:
        return api.send(obj.set())


def send_raw(msg: str) -> str:
    with comm.api_context() as api:
        return api.send(msg)


def error() -> str:
    return send_raw("get_errors")


def interrupt_routing() -> str:
    """Utility function to interrupt long running routing jobs in
    the server.

    When a routing job or a sequence of routing jobs are ongoing, the
    user can choose to prematurely terminate the routing.

    Returns
    -------
    str

    """
    return send_raw("system_interrupt_routing")


def query_DAC_lsb_mV() -> str:
    """Query LSB value of the DAC channels.

    Returns
    -------
    str

    Notes
    -----
    This value is only valid when doing voltage stimulation.

    """
    return send_raw("system_query_dac_lsb_mv")


class Timing:
    """Class defining suitable wait times after various commands to ensure proper execution.

    These can be used with the time.sleep() command after executing the respective commands.

    Attributes
    ----------
    waitInit : int
        How many seconds to wait after :py:func:`mx.initialize()<maxlab.util.initialize()>`. Equal to 2.
    waitAfterDownload : int
        How many seconds to wait after :py:meth:`mx.Array.download()<maxlab.chip.Array.download()>`. Equal to 5.
    waitInMX1Offset : int
        How many seconds to wait after :py:func:`mx.offset()<maxlab.util.offset()>` for MaxOne. Equal to 5.
    waitInMX2Offset : int
        How many seconds to wait after :py:func:`mx.offset()<maxlab.util.offset()>` for MaxTwo. Equal to 15.
    waitAfterRecording : int
        How many seconds to wait after :py:meth:`mx.Saving.stop_recording()<maxlab.saving.Saving.stop_recording()>`. Equal to 2.

    Examples
    --------
    >>> mx.initialize()
    >>> time.sleep(mx.Timing.waitInit)

    """
    waitInit = 2
    waitAfterDownload = 5
    waitAfterOffset = 5
    waitInMX1Offset = 5
    waitInMX2Offset = 15
    waitAfterBankSwitch = 2
    waitAfterRecording = 2


def clear_events() -> None:
    """Clear all events in the event buffer.

    Notes
    -----
    This removes all events from the internal event buffer.

    """
    send_raw("system_clear_events")


def electrode_neighbors(index: int, radius: int) -> List[int]:
    """Given an index on the chip, i.e. an electrode number and a radius, this function
    returns the numbers of the neighboring electrodes.

    Parameters
    ----------
    index: `int`
        Electrode index.
    radius: `int`
        Radius to consider, where the value corresponds to the logical Euclidean Distance (lED) between
        the points on the grid. As an example, consider this simple 3 x 6 grid

        .. code-block::

                 0         5
                +-+-+-+-+-+-+
              0 | |A| | | | |
                +-+-+-+-+-+-+
                | | | | | | |   lED(A, B) = sqrt(abs(0-2)**2 + abs(1-4)**2) ~ 3.60
                +-+-+-+-+-+-+
              2 | | | | |B| |
                +-+-+-+-+-+-+

        i.e. assuming `index` is the position of `A`, then setting `radius` to `>=4` will capture `B`,
        otherwise it will not.

    Returns
    -------
    indices: `List[int]`

    Examples
    --------
    >>> neighbors(45, 1)
    [44, 46, 265]
    >>> neighbors(789, 2)
    [349, 568, 569, 570, 787, 788, 790, 791, 1008, 1009, 1010, 1229]
    """
    assert radius > 0
    assert 0 <= index <= 26399

    num_rows, num_cols = 120, 220
    neighbors = []
    row = int(index / num_cols)
    col = int(index % num_cols)
    for i in range(max(0, row - radius), min(num_rows, row + radius + 1)):
        for j in range(max(0, col - radius), min(num_cols, col + radius + 1)):
            if (
                i * num_cols + j != index
                and (((row - i) ** 2 + (col - j) ** 2) ** 0.5 - radius) < 1e-2
            ):
                neighbors.append(i * num_cols + j)
    return neighbors


def set_event_threshold(threshold: float) -> None:
    """Set the spike detection threshold for the system.

    Parameters
    ----------
    threshold : float
        The threshold value to set, in standard deviations away from the mean.

    Returns
    -------
    None

    Examples
    --------
    >>> mx.set_event_threshold(3.5)
    >>> mx.set_event_threshold(5.5)

    Notes
    -----
    This function does not update Scope. Make sure to either restart scope if you have it open, or set the threshold
    back to the default value of ``5.0``.
    """
    send_raw(f"stream_set_event_threshold {threshold}")
