import sys


def is_py2() -> bool:
    return True if sys.version_info[0] == 2 else False


def decode(obj):  # type: ignore
    return obj if is_py2() else obj.decode("latin1")  # type: ignore


def encode(obj):  # type: ignore
    return obj if is_py2() else str.encode(obj, "latin1")  # type: ignore
