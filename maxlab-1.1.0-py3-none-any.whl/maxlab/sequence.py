from . import comm
from .system import DelaySamples
from .api_object import ApiObject
from typing import Optional

__all__ = ["Sequence"]


class Sequence:
    r"""Holds a sequence of commands.

    Parameters
    ----------

    name : Optional[str]
        The name associated with the sequence. If not provided, a new
        token will be generated.

    initial_delay : int
        The number of samples to delay the first command in the sequence.

    persistent : bool
        Indicates whether the sequence should persist on the server even
        after the Sequence object is deleted. In principle, you can trigger
        the sequence from C++ even after the python object associated to it
        has been deleted.

    Notes
    -----
    The commands contained in a sequence are executed immediately one
    after each other.

    Thus, the timing between consecutive commands can be precisely
    controlled, down to a resolution of 50 µs. The jitter between
    consecutive commands is negligible with respect to 50 µs,
    and this is relevant for sequences implementing electrical stimulation
    pulses. For a more detailed explanation, please see the introduction
    of this document.

    In case the first command of the sequence gets executed
    before all remaining commands were successfully downloaded,
    the timing would be no longer precise. To prevent this from
    happening, it is good practise to insert a delay command right at
    the beginning of the sequence. This is done through  the parameter
    `initial_delay`. Delaying for 100 samples (i.e. 5 ms) should be
    enough in virtually all cases.

    The sequences are managed on the server and one can generate as many
    sequences as needed. They will be maintained on the server. Whenever
    a sequence object in the python code gets deleted, either through
    explicitely calling `del` or if the code goes out of scope, the
    respective sequence in the server will also be removed:

    >>> s1 = maxlab.Sequence()
    >>> s1.append( maxlab.system.DelaySamples(4) )
    >>> del s1 # All information about Sequence s1 is removed from the server
    >>>
    >>> def func(samples):
    >>>     s = maxlab.Sequence()
    >>>     s.append(maxlab.system.DelaySamples(samples))
    >>>     return 0 # As soon as the function finishes, the sequence s is removed from the server

    """

    def __init__(self, name: Optional[str] = None, initial_delay: int = 100, persistent: bool = False) -> None:
        self.persistent = persistent

        with comm.api_context() as api:
            # request a new sequence and save its token
            if name is None:
                self.token = api.send("sequence_new")
            else:
                self.token = api.send("sequence_new " + name)

        if initial_delay > 0:
            self.append(DelaySamples(initial_delay))

    def shutdown(self) -> None:
        with comm.api_context() as api:
            if not self.persistent:
                api.send("sequence_delete " + self.token)

    def __del__(self) -> None:
        self.shutdown()

    def append(self, obj: ApiObject) -> "Sequence":
        """Append the ApiObject `obj` to the sequence.

        Parameters
        ----------
        obj : ApiObject
            ApiObject to be appended to the sequence.

        Returns
        -------
        maxlab.sequence.Sequence
            The Sequence object itself after appending, not a new sequence.

        """
        with comm.api_context() as api:
            api.send("sequence_append " + self.token + "\n" + obj.set())
            return self

    def send(self) -> "Sequence":
        """Sends the sequence to the system.

        This method downloads the sequence to the MaxOne Hub/MaxTwo, from where
        it gets executed, command by command.

        Returns
        -------
        maxlab.sequence.Sequence
            The Sequence object itself after sending, not a new sequence.

        """
        with comm.api_context() as api:
            api.send("sequence_send " + self.token)
            return self
