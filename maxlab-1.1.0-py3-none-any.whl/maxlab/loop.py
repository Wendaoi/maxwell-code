from . import comm


class Loop:
    @staticmethod
    def prepare() -> None:
        with comm.api_context() as api:
            api.send("system_loop_prepare")

    @staticmethod
    def finish() -> None:
        with comm.api_context() as api:
            api.send("system_loop_finish")

    @staticmethod
    def download() -> None:
        with comm.api_context() as api:
            api.send("system_loop_download")

    @staticmethod
    def start() -> None:
        with comm.api_context() as api:
            api.send("system_loop_start")

    @staticmethod
    def stop() -> None:
        with comm.api_context() as api:
            api.send("system_loop_stop")

    @staticmethod
    def run_once() -> None:
        with comm.api_context() as api:
            api.send("system_loop_run_once")

    @staticmethod
    def append_delay(samples: int) -> None:
        with comm.api_context() as api:
            api.send("system_loop_append_delay " + str(samples))

    @staticmethod
    def append_dac(code: int, value: int) -> None:
        with comm.api_context() as api:
            api.send("system_loop_append_dac " + str(code) + " " + str(value))

    @staticmethod
    def append_event(well_id: int, event_type: int, user_id: int, properties: str) -> None:
        with comm.api_context() as api:
            api.send(
                "system_loop_event " + str(well_id) + " " + str(event_type) + " " + str(user_id) + " " + properties
            )
