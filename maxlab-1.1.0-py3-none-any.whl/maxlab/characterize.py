from .util import send, send_raw
from .chip import DAC, Bias, Core, Array, StimulationUnit, power_down_all_stimulation_buffers
from .system import Switches
from .pycompat import encode
from typing import List

import time
import struct

__all__ = ["power_down_all_readout_channels_except", "get_mean", "binary_search_code", "StimulationUnitCharacterizer"]


def power_down_all_readout_channels_except(channel: int) -> None:
    block = int(channel / 128)
    value = (2**8 - 1) - 2**block
    send(Bias(0, 0, value))


def get_mean() -> List[float]:
    ret = send_raw("system_mean")
    return [float(x) for x in ret.split(",") if x != ""]


def binary_search_code(
    readout_channel: int,
    target: float,
    min_code: int = 0,
    max_code: int = 1024,
    sleeptime: float = 1.2,
    debug: bool = False,
) -> int:
    span = int((max_code - min_code) / 2)
    last_code = int((max_code - min_code) / 2)
    current_code = last_code

    while True:
        # Set the DAC code
        send(DAC(0, current_code))

        # Sleep for the given amount
        time.sleep(sleeptime)

        # Get the deviation from target
        mean = get_mean()

        diff = mean[readout_channel] - target
        span = span / 2.0
        current_code = int(current_code + span) if diff > 0.5 else int(current_code - span)

        if debug:
            print(span, current_code, mean[readout_channel], target, diff)

        if current_code == last_code:
            break

        last_code = current_code

    return last_code


class StimulationUnitCharacterizer(object):
    def __init__(self) -> None:
        core = Core()
        core.enable_stimulation_power(True)
        core.use_external_port(True)
        send(core)
        self.array = Array("current")

    def connect_stimulation_unit_to_external_port(self, unit_no: int) -> StimulationUnit:
        stim_unit = StimulationUnit(unit_no)
        readout_channel = stim_unit.get_readout_channel()

        # Power down all NOT needed blocks of readout channels, to avoid kickback noise
        # power_down_all_readout_channels_except(readout_channel)

        # Power down all stimulation buffers
        power_down_all_stimulation_buffers()

        # Connect the corresponding readout channel to the stimBuffer
        self.array.connect_amplifier_to_stimulation(readout_channel)

        # Connect the corresponding readout channel to the VRef ring of the array
        self.array.connect_amplifier_to_ringnode(readout_channel)

        self.array.download()

        # Power up the correct stimulation unit
        stim_unit.power_up(True).connect(True).set_current_mode().set_large_current_range().dac_source(0)
        send(stim_unit)
        return stim_unit

    def disconnect_stimulation_unit_from_external_port(self, unit_no: int) -> None:
        stim_unit = StimulationUnit(unit_no)
        readout_channel = stim_unit.get_readout_channel()

        # Power down all stimulation buffers
        power_down_all_stimulation_buffers()

        # Disconnect the corresponding readout channel to the stimBuffer
        self.array.disconnect_amplifier_from_stimulation(readout_channel)

        # Disconnect the corresponding readout channel to the VRef ring of the array
        self.array.disconnect_amplifier_from_ringnode(readout_channel)

    def characterize(self, unit_no: int) -> int:
        stim_unit = StimulationUnit(unit_no)
        readout_channel = stim_unit.get_readout_channel()

        # Connect the 1M Ohm resistor to ProbeIn
        sw = Switches(1, 0, 0, 0, 1, 0, 0, 1)
        send(sw)

        # Connect stimulation unit to external port
        stim_unit = self.connect_stimulation_unit_to_external_port(unit_no)

        # Disconnect the stimulation unit to read tearget mean
        stim_unit.connect(False)
        send(stim_unit)

        # Get the target mean value to achieve
        time.sleep(2)
        target = get_mean()[readout_channel]
        time.sleep(2)

        # Power up the stimulation unit
        stim_unit.connect(True)
        send(stim_unit)

        # Binary search for the correct code
        code = binary_search_code(readout_channel, target)

        # Disconnect stimulation unit from external port
        self.disconnect_stimulation_unit_from_external_port(unit_no)

        # Load the original switch configuration
        sw = Switches(1, 0, 0, 0, 1, 0, 0, 0)
        send(sw)

        return code
