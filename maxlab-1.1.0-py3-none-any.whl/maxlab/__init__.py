#!/usr/bin/python
# -*- coding: utf-8
"""
Python module for programmatic control of MaxLab Live.

.. moduleauthor:: Jan Mueller <jan.mueller@mxwbio.com>

"""

import sys

assert sys.version_info[0] == 3, f"The API is intended to be used with Python 3. You are currently using Python {sys.version_info[0]}."

from .characterize import *
from .chip import *
from .config import *
from .loop import *
from .saving import *
from .sequence import *
from .stream import *
from .system import *
from .util import *
from .wellplate import *

from . import comm
from . import characterize
from . import chip
from . import config
from . import loop
from . import saving
from . import sequence
from . import stream
from . import system
from . import util
from . import wellplate

__version__ = "1.1.0"
__git_hash__ = "9c79a6037"
