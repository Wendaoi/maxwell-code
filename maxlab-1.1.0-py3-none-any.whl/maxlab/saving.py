#!/usr/bin/python
# -*- coding: utf-8
from . import comm
from typing import List, Optional

__all__ = ["Saving"]


class Saving:
    # COMPAT
    def start(self, file_name: str = "") -> None:
        with comm.api_context() as api:
            api.send("saving_start " + file_name)

    # COMPAT
    def start_spikes_only(self, file_name: str = "") -> None:
        with comm.api_context() as api:
            api.send("saving_spikes_only " + file_name)

    # COMPAT
    def stop(self) -> None:
        with comm.api_context() as api:
            api.send("saving_stop")

    def set_legacy_format(self, use: bool = True) -> None:
        """Set the legacy file format for saving.

        Parameters
        ----------
        use : bool, default True
            If True, the legacy file format is used for saving.
            If False, the new file format is used for saving.

        Returns
        -------
        None

        Notes
        -----
        If the new data format is used and we want to also store the signal traces,
        we must declare which electrodes we want to store data from. This can be set through
        the :py:meth:`group_define()<maxlab.saving.Saving.group_define()>` method.

        """
        with comm.api_context() as api:
            api.send("saving_use_old_file_format " + str(int(use)))

    def start_file(self, file_name: str) -> None:
        """Initialize a recording file

        This method initialize an emtpy recording file and
        needs to be run before calling :py:meth:`start_recording()<maxlab.saving.Saving.start_recording()>`.

        Parameters
        ----------
        file_name : str
            The filename in which the data is recorded.

        Returns
        -------
        None

        """
        with comm.api_context() as api:
            api.send("saving_start_file " + file_name)

    def stop_file(self) -> None:
        """Terminate a recording file

        This method terminates the filled recording file and
        needs to be run after calling :py:meth:`stop_recording()<maxlab.saving.Saving.stop_recording()>`.

        Returns
        -------
        None

        """
        with comm.api_context() as api:
            api.send("saving_stop_file")

    def start_recording(self, wells: Optional[List[int]] = None) -> None:
        """Start the recording

        This method starts the recording and needs to be run
        after the initialization of the recording file with the
        method :py:meth:`start_file()<maxlab.saving.Saving.start_file()>`.

        Optionally, the method can take as parameter which
        wells we wish to record data from.

        Parameters
        ----------
        wells : List[int], optional
            List of well indices specifying from which well we want to
            record data.

        Returns
        -------
        None

        """
        if wells is None:
            wells = [0]

        with comm.api_context() as api:
            api.send("saving_set_recording_wells " + ",".join([str(w) for w in wells]))
            api.send("saving_start_recording")

    def stop_recording(self) -> None:
        """Stop the recording

        This method stops the recording and needs to be run
        before the termination of the recording file with the
        method :py:meth:`stop_file()<maxlab.saving.Saving.stop_file()>`.

        Results
        -------
        None

        """
        with comm.api_context() as api:
            api.send("saving_stop_recording")

    def open_directory(self, directory_name: str) -> None:
        """Open the recording directory

        This methods open the directory where the data will
        be saved. It needs to be run before initializing the file
        with the method :py:meth:`start_file()<maxlab.saving.Saving.start_file()>`
        and it takes as parameter the directory name, i.e., the path.

        Parameters
        ----------
        directory_name : str
            Directory name, i.e., path, to where we wish to save
            the recording data.

        Returns
        -------
        None

        """
        with comm.api_context() as api:
            api.send("saving_open_dir " + directory_name)

    def record_wells(self, wells: List[int]) -> None:
        """Set the wells that should be recorded in the files

        Parameters
        ----------
        wells : List[int]
            List of well indices.

        Returns
        -------
        None

        """
        with comm.api_context() as api:
            api.send("saving_set_recording_wells " + ",".join([str(w) for w in wells]))

    def group_define(self, well: int, name: str, channels: List[int] = []) -> str:
        """Define the recording groups

        This method sets which electrodes we want to store the data from and their
        respective grouping. It is only used for the new file format (legacy_file_format = False)
        and if we want to store the signal traces. The parameter `name` sets the
        group name used for these electrodes, e.g., "all_channels":

        >>> s.group_define(0, "all_channels", range(1024))

        This method needs to be called before starting the recordings with
        :py:meth:`start_recording()<maxlab.saving.Saving.start_recording()>`, but after the initialization
        of the file with :py:meth:`start_file()<maxlab.saving.Saving.start_file()>` . It is recommended
        to delete potential already-existing groups before running
        :py:meth:`group_define()<maxlab.saving.Saving.group_define()>`, by running the method
        :py:meth:`group_delete_all()<maxlab.saving.Saving.group_delete_all()>`.

        Parameters
        ----------
        well : int
            Well index specifying from which well to store data from.
        name : str
            Name of the group used for the recording electrodes.
        channels : List[int]
            List of channels to record from. Values range from 0 to 1023,
            which is the maximal number of recording channels.

        Returns
        -------
        str
            "ok" if the groups were correctly defined, else "error".

        Notes
        -----
        If needed, we can also define multiple groups for same recording, with a set
        of channels. These groups can also have overlapping channels.
        
        Channels that are not connected to an electrode still transmit data to the software; 
        however, these values are not meaningful. It is the user’s responsibility to select 
        appropriate, connected channels for recording and to consider only relevant channels 
        during analysis.



        """
        channels = [c for c in channels if 0 <= c < 1024]
        with comm.api_context() as api:
            return api.send("saving_group_define %d %s %s" % (well, name, ",".join([str(c) for c in channels])))

    def group_set_trigger(
            self,
            well: int,
            name: str,
            channels: List[int],
            pre: int = 100,
            post: int = 100,
            min_amp: int = -10000,
            max_amp: int = 10000,
    ) -> str:
        channels = [c for c in channels if 0 <= c < 1024]
        with comm.api_context() as api:
            return api.send(
                "saving_group_trigger %d %s %s %d %d %f %f"
                % (well, name, ",".join([str(c) for c in channels]), pre, post, min_amp, max_amp)
            )

    def group_clear_trigger(self, well: int, name: str) -> str:
        with comm.api_context() as api:
            return api.send("saving_group_trigger %d %s clear" % (well, name))

    def group_delete(self, well: int, name: str) -> str:
        """Delete a specific group

        This method deletes a specific group from the recording file and
        as defined by the method :py:meth:`group_define()<maxlab.saving.Saving.group_define()>`.
        It takes as input the well index and the group name.

        Parameters
        ----------
        well : int
            Well index.
        name : str
            Group name.

        Returns
        -------
        str
            "ok" if the group was succesfully deleted, else "error".

        """
        with comm.api_context() as api:
            return api.send("saving_group_delete %d %s" % (well, name))

    def group_delete_well(self, well: int) -> str:
        """Delete a specific well

        This method deletes a specific well from the recording file and as defined by the
        method :py:meth:`group_define()<maxlab.saving.Saving.group_define()>`. It takes
        as input the well index.

        Parameters
        ----------
        well : int
            Well index.

        Returns
        -------
        str
            "ok" if the well was succesfully deleted, else "error".

        """
        with comm.api_context() as api:
            return api.send("saving_group_clear %d" % well)

    def group_delete_all(self) -> str:
        """Delete all groups

        This method deletes all group from the recording, as defined
        by the method :py:meth:`group_define()<maxlab.saving.Saving.group_define()>`.

        Returns
        -------
        str
            "ok" if the groups were succesfully deleted, else "error".

        """
        with comm.api_context() as api:
            return api.send("saving_group_clear")

    def group_info(self, well: int) -> str:
        with comm.api_context() as api:
            return api.send("saving_group_info %d" % well)

    def write_assay_property(self, key: str, value: str) -> str:
        with comm.api_context() as api:
            return api.send("saving_set_assay_property " + key + " " + value)

    def write_assay_input(self, key: str, value: str) -> str:
        with comm.api_context() as api:
            return api.send("saving_set_assay_input " + key + " " + value)
