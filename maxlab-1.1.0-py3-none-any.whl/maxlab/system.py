#!/usr/bin/python
# -*- coding: utf-8

from .api_object import ApiObject

__all__ = [
    "DelaySamples",
    "DelayCycles",
    "MidSupply",
    "ReferenceStimulationHigh",
    "ReferenceStimulationMiddle",
    "ReferenceStimulationLow",
    "ReferenceADCStart",
    "ReferenceADCStop",
    "ReferenceRampGen",
    "ReferenceMOSResistor",
    "ReferenceVoltage",
    "Switches",
    "GPIODirection",
    "GPIOOutput",
    "StatusLED",
    "StatusOut",
    "Event",
]


class DelaySamples(ApiObject):
    """Insert a delay between two consecutive commands

    Parameters
    ----------
    samples : int
        How many samples to delay between two consecutive
        commands. Time between two recording samples is 50 µs and
        is independent of the data sampling rate, i.e it is the same
        for MaxOne and MaxTwo.

    """

    def __init__(self, samples: int = 0) -> None:
        self.samples = samples

    def set(self) -> str:
        return "system_delay_samples " + str(self.samples)


class DelayCycles(ApiObject):
    """Insert a cycle delay between two consecutive commands

    Parameters
    ----------
    cycles : int
        How many cycles to delay between two consecutive
        commands. One cycle is 1/24MHz, maximum number of cycles to
        wait is 2^24.

    Notes
    -----
    This command is not recommended to be used.

    """

    def __init__(self, cycles: int = 0) -> None:
        self.cycles = cycles

    def set(self) -> str:
        return "system_delay_cycles " + str(self.cycles)


class MidSupply(ApiObject):
    def __init__(self, reference_voltage: int = 128) -> None:
        self.reference_voltage = reference_voltage

    def set(self) -> str:
        return "system_set_mid_supply " + str(self.reference_voltage)


class ReferenceStimulationHigh(ApiObject):
    """Sets the high reference voltage for the stimulation buffers.

    Parameters
    ----------
    reference_voltage : int
        Value in bits to set the reference
        voltage. Allowed values are between 0 and 4095, whereas
        4095 corresponds to 3.3 volts. When doing voltage controlled
        stimulation, the recommended default value for this reference
        voltage is 2.25 volts, i.e. 2792 bits.

    """

    def __init__(self, reference_voltage: int = 2820) -> None:
        self.reference_voltage = reference_voltage

    def set(self) -> str:
        return "system_set_reference_stimulation_high " + str(self.reference_voltage)


class ReferenceStimulationMiddle(ApiObject):
    def __init__(self, reference_voltage: int = 2048) -> None:
        self.reference_voltage = reference_voltage

    def set(self) -> str:
        return "system_set_reference_stimulation_middle " + str(self.reference_voltage)


class ReferenceStimulationLow(ApiObject):
    """Sets the low reference voltage for the stimulation buffers.

    Parameters
    ----------
    reference_voltage : int
        Value in bits to set the reference
        voltage. Allowed values are between 0 and 4095, whereas
        4095 corresponds to 3.3 volts. When doing voltage controlled
        stimulation, a typically recommended value for this reference
        voltage is 1.05 volts, i.e. 1304.

    Notes
    -----
    Refer to the system manual for more details about this reference
    voltage.

    """

    def __init__(self, reference_voltage: int = 1304) -> None:
        self.reference_voltage = reference_voltage

    def set(self) -> str:
        return "system_set_reference_stimulation_low " + str(self.reference_voltage)


class ReferenceADCStart(ApiObject):
    def __init__(self, reference_voltage: int = 6) -> None:
        self.reference_voltage = reference_voltage

    def set(self) -> str:
        return "system_set_reference_adc_start " + str(self.reference_voltage)


class ReferenceADCStop(ApiObject):
    def __init__(self, reference_voltage: int = 45) -> None:
        self.reference_voltage = reference_voltage

    def set(self) -> str:
        return "system_set_reference_adc_stop " + str(self.reference_voltage)


class ReferenceRampGen(ApiObject):
    def __init__(self, reference_voltage: int = 2048) -> None:
        self.reference_voltage = reference_voltage

    def set(self) -> str:
        return "system_set_reference_rampgen " + str(self.reference_voltage)


class ReferenceMOSResistor(ApiObject):
    def __init__(self, reference_voltage: int = 4095) -> None:
        self.reference_voltage = reference_voltage

    def set(self) -> str:
        return "system_set_reference_mos_resistor " + str(self.reference_voltage)


class ReferenceVoltage(ApiObject):
    def __init__(self, reference_voltage: int = 2048) -> None:
        self.reference_voltage = reference_voltage

    def set(self) -> str:
        return "system_set_reference_voltages " + str(self.reference_voltage)


class VariableReference(ApiObject):
    def __init__(self, reference_voltage: int = 2048) -> None:
        self.reference_voltage = reference_voltage

    def set(self) -> str:
        return "system_set_variable_reference " + str(self.reference_voltage)


class Switches(ApiObject):
    def __init__(
        self,
        sw_0: int = 1,
        sw_1: int = 1,
        sw_2: int = 0,
        sw_3: int = 0,
        sw_4: int = 0,
        sw_5: int = 0,
        sw_6: int = 0,
        sw_7: int = 0,
    ) -> None:
        self.sw = [sw_0, sw_1, sw_2, sw_3, sw_4, sw_5, sw_6, sw_7]

    def get(self) -> str:
        return "system_get_switches"

    def set(self) -> str:
        return "system_set_switches " + " ".join([str(sw) for sw in self.sw])


class GPIODirection(ApiObject):
    """Set the direction of the GPIOs.

    Please refer to the glossary if you are not sure what GPIO means.

    Parameters
    ----------
    direction : int
        An 8-bit value, where each bit of `direction` controls the
        state of one GPIO, whether one GPIO is either in input or
        in output mode.

        * bit = '0': setting the corresponding GPIO channel into input mode.
        * bit = '1': setting the corresponding GPIO channel into output mode.

    Notes
    -----
    When the GPIO is set to input mode, the value applied to the GPIO
    pin is sampled together with each sampling frame of the MaxOne/MaxTwo chip
    and the values are recorded into the recording file.

    Examples
    --------
    >>> # This sets GPIO3 to output mode, GPIO7 - GPIO4 and GPIO2 - GPIO0 to input mode
    >>> maxlab.send( maxlab.system.GPIODirection(0b00001000))

    """

    def __init__(self, direction: int = 0) -> None:
        self.direction = direction

    def set(self) -> str:
        return "system_set_gpio_direction " + str(self.direction)


class GPIOOutput(ApiObject):
    """Control the output of the GPIOs.

    Please refer to the glossary if you are not sure what GPIO means.

    Parameters
    ----------
    output : int
        An 8-bit value specifying the output state of each GPIO channel.

    Notes
    -----
    When the corresponding bit is set to output mode with
    :func:`maxlab.system.GPIODirection`, the output of that channel can
    be controlled through this function.

    Examples
    --------
    The following example generates a pulse on the GPIO channel 3,
    by toggling bit 4:

    >>> maxlab.send( maxlab.system.GPIOOutput(0b1000))
    >>> maxlab.send( maxlab.system.DelaySamples(100))
    >>> maxlab.send( maxlab.system.GPIOOutput(0b0000))

    """

    def __init__(self, output: int = 0) -> None:
        self.output = output

    def set(self) -> str:
        return "system_set_gpio_output " + str(self.output)


class StatusLED(ApiObject):
    """Control the color of the status LED.

    Parameters
    ----------
    color : int
        Value to control the color of the LED on the Recording Unit.

        Values for the color parameter can be:
            * 0: light blue.
            * 1: cyan.
            * 2: pink
            * 3: dark blue
            * 4: light green
            * 5: dark green
            * 6: red
            * 7: off

    Notes
    -----
    When the experiment is light sensitive, for example during a retina experiment,
    this LED can be switched off by setting the `color` parameter to 7.

    """

    def __init__(self, color: int = 0) -> None:
        self.color = color

    def set(self) -> str:
        return "system_set_status_led " + str(self.color)


class StatusOut(ApiObject):
    """Send status bits

    Parameters
    ----------
    status : int
        Value used to set the status bits.

    """

    def __init__(self, status: int = 0) -> None:
        self.status = status

    def set(self) -> str:
        return "system_status_out " + str(self.status)


class Event(ApiObject):
    """Triggers the sending of an event which is then converted to status_out command

    Parameters
    ----------
    well_id : int
        ID of the specific well.
    event_type : int
        The type of the event. At the moment, the `event_type` needs to be `1`.
    user_id : int
        Custom event identifier assigned by the user. Further we have 1 <= user_id <= 2**20-1.
        Be careful that user_id can not be 0.
    properties : str
        Additional properties associated with the event. Space separated key, value pairs, i.e.
        ``"key_1 value_1 key_2 value_2"``.

    Examples
    --------
    >>> mx.Event(0, 1, event_id, f"custom_id {number}")

    Notes
    --------
    Events, along with the frame number at which they occur, are stored in the recording file. If they are sent before
    a stimulation pulse within a sequence, they will share the same frame number as the onset of the stimulation and can,
    therefore, be used to identify the exact timing of the stimulation.

    The combination of the ``well_id`` and ``user_id`` must be unique for different events.

    """

    def __init__(
        self, well_id: int, event_type: int, user_id: int, properties: str
    ) -> None:
        self.well_id = well_id
        self.event_type = event_type
        self.user_id = user_id
        self.properties = properties

    def set(self) -> str:
        return (
            "system_trigger_event "
            + str(self.well_id)
            + " "
            + str(self.event_type)
            + " "
            + str(self.user_id)
            + " "
            + self.properties
        )
