from . import comm

__all__ = ["WellPlate"]


class WellPlate(object):
    """Interface to query various properties of the currently configured wellplate."""

    @staticmethod
    def __send(command: str) -> str:
        with comm.api_context() as api:
            return api.send(command)

    def query_version(self) -> str:
        """Returns the integer for the wellplate version

        Returns
        -------
        str

        """
        return self.__send("wellplate_query_version")

    def query_rows(self) -> str:
        """Returns the number of well-rows in the wellplate

        Returns
        -------
        str

        """
        return self.__send("wellplate_query_rows")

    def query_columns(self) -> str:
        """Returns the number of well-rows in the wellplate

        Returns
        -------
        str

        """
        return self.__send("wellplate_query_columns")
