#!/usr/bin/python
# -*- coding: utf-8
from . import comm
from .api_object import ApiObject
from .config import Config
from typing import List, Optional, Union


__all__ = [
    "power_down_all_stimulation_buffers",
    "Amplifier",
    "Core",
    "RampGen",
    "Controller",
    "Bias",
    "ResetDisconnect",
    "DAC",
    "StimulationUnit",
    "Offset",
    "Array",
]


class Amplifier(ApiObject):
    """Program gain of the MaxOne/MaxTwo on-chip amplifiers.

    Parameters
    ----------
    gain : int
        The gain to be set.

    Notes
    -----
    Default gain for this command is 512. Use :meth:`maxlab.chip.Amplifier.set_gain` to set a different gain.

    """

    def __init__(self, gain: int = 512) -> None:
        self = self.set_gain(gain)

    def params(
        self,
        stage1_bypass: int = 0,
        stage1_gain: int = 1,
        stage1_reset_mode: int = 0,
        stage2_bypass: int = 0,
        stage2_gain: int = 5,  # 5 == x16
        stage3_bypass: int = 0,
        stage3_gain: int = 0,
    ) -> "Amplifier":
        self.settings = [
            stage1_bypass,
            stage1_gain,
            stage1_reset_mode,
            stage2_bypass,
            stage2_gain,  # 5 == x16
            stage3_bypass,
            stage3_gain,
        ]
        return self

    def set(self) -> str:
        return "mea_set_amplifier " + " ".join([str(settings) for settings in self.settings])

    def set_gain(self, gain: int) -> "Amplifier":
        """Set different gain values for the amplifier.

        Parameters
        ----------
        gain : int
            The gain to be set.

            Possible gain values are:
                * 1
                * 7
                * 112
                * 512
                * 1024
                * 1025
                * 2048

        Notes
        -----
        Other values are not valid and will raise an exception. For example trying to set the gain to 1000:

        Raises
        ------
        ValueError
            If `gain` is not a valid gain setting.

        Examples
        --------
        >>> try:
        >>>     maxlab.chip.Amplifier().set_gain(1000)
        >>> except ValueError as error:
        >>>     print(error.args[0])
        Not a valid gain parameter: 1000

        """
        if gain == 1:
            return self.params(1, 0, 0, 1, 0, 1, 0)
        if gain == 7:
            return self.params(0, 0, 0, 1, 0, 1, 0)
        if gain == 112:
            return self.params(0, 0, 0, 0, 4, 0, 0)
        if gain == 512:
            return self.params(0, 1, 0, 0, 5, 0, 0)
        if gain == 1024:
            return self.params(0, 1, 0, 0, 5, 0, 1)
        if gain == 1025:
            return self.params(0, 1, 0, 0, 6, 0, 0)
        if gain == 2048:
            return self.params(0, 1, 0, 0, 6, 0, 1)
        raise ValueError("Not a valid gain parameter: " + str(gain))


class Core(ApiObject):
    """Control core settings of the MaxOne/MaxTwo chip."""

    def __init__(self) -> None:
        self.params(
            enable_external_port=False,
            stimulation_power=True,
            controller_multiplication=0,
            output_enable=True,
            tx_mode=0,
            reset_mode=0,
            reset_speed=7,
        )

    def params(
        self,
        enable_external_port: bool = False,
        stimulation_power: bool = True,
        controller_multiplication: int = 0,
        output_enable: bool = True,
        tx_mode: int = 0,
        reset_mode: int = 0,
        reset_speed: int = 7,
    ) -> "Core":
        self.enable_external_port = enable_external_port
        self.stimulation_power = stimulation_power
        self.controller_multiplication = controller_multiplication
        self.output_enable = output_enable
        self.tx_mode = tx_mode
        self.reset_mode = reset_mode
        self.reset_speed = reset_speed
        return self

    def set(self) -> str:
        return (
            "mea_set_core  "
            + str(int(self.enable_external_port))
            + " "
            + str(int(self.stimulation_power))
            + " "
            + str(int(self.controller_multiplication))
            + " "
            + str(int(self.output_enable))
            + " "
            + str(int(self.tx_mode))
            + " "
            + str(int(self.reset_mode))
            + " "
            + str(int(self.reset_speed))
        )

    def use_external_port(self, enable: bool) -> "Core":
        """Enables the external port access to the array.

        Parameters
        ----------
        enable : bool
            True if external port is used.

        Returns
        -------
        maxlab.chip.Core

        """
        self.enable_external_port = enable
        return self

    def enable_stimulation_power(self, enable: bool) -> "Core":
        """Powers up the Stimulation Units and enables stimulations to be delivered to the array.

        Parameters
        ----------
        enable : bool
            True if stimulation power is enabled.

        Returns
        -------
        maxlab.chip.Core
        """
        self.stimulation_power = enable
        return self

    def set_controller_multiplication(self, multiplication: int) -> "Core":
        """Sets the multiplication stage in the Controller.

        Parameters
        ----------
        multiplication : int
            possible values are: 0 (1x), 1 (2x), 2 (4x)

        Returns
        -------
        maxlab.chip.Core

        """
        self.controller_multiplication = multiplication
        return self

    def enable_digital_output(self, enable: bool) -> "Core":
        self.output_enable = enable
        return self

    def set_tx_mode(self, mode: int) -> "Core":
        self.tx_mode = mode
        return self

    def set_reset_mode(self, mode: int) -> "Core":
        self.reset_mode = mode
        return self

    def set_reset_speed(self, speed: int) -> "Core":
        self.reset_speed = speed
        return self


class RampGen(ApiObject):
    """Control RampGen settings of the MaxOne/MaxTwo chip.

    Paramters
    ---------
    enable : bool

    amplifier : int

    """

    def __init__(self, enable: bool = True, amplifier: int = 4) -> None:
        self.enable = enable
        self.amplifier = amplifier

    def set(self) -> str:
        return "mea_set_rampgen  " + str(int(self.enable)) + " " + str(int(self.amplifier))


class Controller(ApiObject):
    """Control Controller (SwitchCap) of the MaxOne/MaxTwo chip.

    Parameters
    ----------
    enable : bool

    ampMult : int

    ampFreq : int

    clkMon1 : int

    clkMon2 : int

    """

    def __init__(
        self, enable: bool = True, ampMult: int = 0, ampFreq: int = 3, clkMon1: int = 0, clkMon2: int = 0
    ) -> None:
        self.enable = enable
        self.ampMult = ampMult
        self.ampFreq = ampFreq
        self.clkMon1 = clkMon1
        self.clkMon2 = clkMon2

    def set(self) -> str:
        return (
            "mea_set_controller  "
            + str(int(self.enable))
            + " "
            + str(int(self.ampMult))
            + " "
            + str(int(self.ampFreq))
            + " "
            + str(int(self.clkMon1))
            + " "
            + str(int(self.clkMon2))
        )


class Bias(ApiObject):
    def __init__(self, value: int = 0, address: int = 0, power_down: int = 0) -> None:
        self.value = value
        self.address = address
        self.power_down = power_down

    def set(self) -> str:
        return "mea_set_bias " + str(self.value) + " " + str(self.address) + " " + str(self.power_down)


class ResetDisconnect(ApiObject):
    def __init__(self, enable: int = 0, broadcast: int = 0, channel: int = 0) -> None:
        self.enable = enable
        self.broadcast = broadcast
        self.channel = channel

    def set(self) -> str:
        return "mea_set_reset_disconnect " + str(self.enable) + " " + str(self.broadcast) + " " + str(self.channel)


class DAC(ApiObject):
    """Program the three on-chip DACs (digital-to-analog converters) channels.

    Parameters
    ----------
    dac_no : int
        Which DAC channel to control.
    dac_code : int
        DAC code in bits.
    dac_code_second : int
        This parameter is only relevant when `dac_no=3`.

    Notes
    -----

    Depending on which DAC channel is specified in the command, the
    parameter `dac_code` has a different meaning.

    The meaning of `dac_code` depending on `dac_no` (DAC channel) is:

     * 0: `dac_code` controls DAC0
     * 1: `dac_code` controls DAC1
     * 2: `dac_code` controls DAC2
     * 3: `dac_code` controls DAC0 and `dac_code_second` controls DAC1 at the very same time.

    The last mode `dac_code=3` is useful for applications where the
    outputs of two DAC channels need to be controlled/changed at the
    exact same time.

    Each DAC channel can be programmed with 10 bits, i.e. possible
    values range between 0 and 1023.  To convert between DAC bits and
    stimulation amplitude, one needs to multiply the DAC bits with the
    value from :func:`maxlab.util.query_DAC_lsb_mV()`.


    Examples
    --------
    When the stimulation buffers are in voltage mode, the conversion
    between DAC code and stimulation voltage goes as follows:

    >>> stimVoltage = (512 - dac_code) * maxlab.query_DAC_lsb_mV()

    """

    def __init__(self, dac_no: int = 0, dac_code: int = 512, dac_code_second: int = 512) -> None:
        self.dac_no = dac_no
        self.dac_code = dac_code
        self.dac_code_second = dac_code_second

    def set(self) -> str:
        return "mea_set_dac " + str(self.dac_no) + " " + str(self.dac_code) + " " + str(self.dac_code_second)


class StimulationUnit(ApiObject):
    """Program the 32 on-chip stimulation units.

    Parameters
    ----------
    unit_no : int
        The stimulation unit to configure.

    Notes
    -----
    When doing voltage stimulation, the amplifier in the stimulation
    unit acts as an inverting amplifier.  A DAC code of 512
    corresponds to mid-supply, i.e. 0-volt stimulation. 512+100
    results in a negative voltage.  512-100 results in a positive
    voltage.

    Examples
    --------
    To convert between bits and stimulation voltage, one needs to know
    the DAC lsb:

    >>> lsb = maxlab.query_DAC_lsb_mV()
    >>> amplitude = -(lsb * bits)

    """

    def __init__(self, unit_no: int) -> None:
        self.unit_no = unit_no
        self.power = 0
        self.do_connect = 0
        self.current_mode = False
        self.current_range = False
        self.dac = 0
        self.ref_source = False
        self.mapping = [
            (0, 796),
            (1, 640),
            (2, 556),
            (3, 384),
            (4, 364),
            (5, 128),
            (6, 84),
            (7, 16),
            (8, 50),
            (9, 130),
            (10, 366),
            (11, 386),
            (12, 558),
            (13, 642),
            (14, 798),
            (15, 898),
            (16, 896),
            (17, 893),
            (18, 773),
            (19, 641),
            (20, 533),
            (21, 385),
            (22, 129),
            (23, 85),
            (24, 1),
            (25, 51),
            (26, 131),
            (27, 387),
            (28, 535),
            (29, 643),
            (30, 775),
            (31, 895),
        ]

    def set(self) -> str:
        return (
            "mea_set_stimulation_unit "
            + str(int(self.unit_no))
            + " "
            + str(int(self.power))
            + " "
            + str(int(self.do_connect))
            + " "
            + str(int(self.current_mode))
            + " "
            + str(int(self.current_range))
            + " "
            + str(int(self.dac))
            + " "
            + str(int(self.ref_source))
        )

    def power_up(self, power_up: bool) -> "StimulationUnit":
        """Power-up this stimulation unit.

        Parameters
        ----------
        power_up : bool
            Enable on-chip power for this particular stimulation unit.

        Returns
        -------
        maxlab.chip.StimulationUnit

        """
        self.power = power_up
        return self

    def connect(self, connect: bool) -> "StimulationUnit":  # i.e. autozeroing
        """Connect or disconnect the stimulation unit.

        Parameters
        ----------
        connect : bool
            Connect or disconnect the output of the unit.

        Returns
        -------
        maxlab.chip.StimulationUnit

        """
        self.do_connect = connect
        return self

    def set_current_mode(self) -> "StimulationUnit":
        """Set the stimulation unit into current mode.

        Returns
        -------
        maxlab.chip.StimulationUnit

        """
        self.current_mode = True
        return self

    def set_voltage_mode(self) -> "StimulationUnit":
        """Set the stimBuffer unit into voltage mode.

        Returns
        -------
        maxlab.chip.StimulationUnit

        """
        self.current_mode = False
        return self

    def set_large_current_range(self) -> "StimulationUnit":  #'large' / 'small'):
        """Set current range to `large` currents when in current mode.

        Returns
        -------
        maxlab.chip.StimulationUnit

        Notes
        -----
        Refer to the system manual to what large means.

        """
        self.current_range = True
        return self

    def set_small_current_range(self) -> "StimulationUnit":  #'large' / 'small'):
        """Set current range to `small` currents when in current mode.

        Returns
        -------
        maxlab.chip.StimulationUnit

        Notes
        -----
        Refer to the system manual to what small means.

        """
        self.current_range = False
        return self

    def dac_source(self, dac: int) -> "StimulationUnit":
        """Choose the DAC channel for the stimulation unit.

        Parameters
        ----------
        dac : int
            The DAC channel to choose for the unit.

            Possible values for DAC channels are:
                * 0=DAC0
                * 1=DAC1
                * 2=DAC2

        Returns
        -------
        maxlab.chip.StimulationUnit

        """
        self.dac = dac
        return self

    def external_reference(self, ref_source: bool = True) -> "StimulationUnit":
        """Use an external reference voltage for this stimulation unit
        instead of a DAC channel.

        Parameters
        ----------
        ref_source : bool
            If `true`, use the external reference source instead of a DAC channel.

        Returns
        -------
        maxlab.chip.StimulationUnit

        """
        self.ref_source = ref_source
        return self

    def get_readout_channel(self) -> int:
        """Get the readout channel for this stimulation unit

        Returns
        -------
        int
            The readout channel for the stimulation unit.

        """
        return next(sCh for sCh in self.mapping if sCh[0] == int(self.unit_no))[1]


class Offset:
    def __init__(self) -> None:
        pass


class Array(ApiObject):
    """Control the electrode array of the MaxOne/MaxTwo chip.

    Parameters
    ----------
    token : str
        Token id to identify this instance on the server. Default is
        'online'
    persistent : bool
        Should the instance of this array get deleted on the server
        when 'close' gets called

    Notes
    -----
    Similarly to :py:class:`maxlab.Sequence<maxlab.sequence.Sequence>`, for each
    :py:class:`maxlab.Array<maxlab.chip.Array>` object there is a counter part on the
    server, which can be uniquely identified through the token id parameter.
    However, differently than for :py:class:`maxlab.Sequence<maxlab.sequence.Sequence>`,
    creating such Array objects on the server is computationally expensive. It takes
    multiple seconds and it consumes significant amounts of RAM.

    One option is to use one of the already
    available array objects, whilst another is to create a new array
    object on the server. The names of the available objects are
    'online' and 'offline'. The online array object is the same controlled
    through MaxLab Live. I.e. when downloading a
    configuration from the scope GUI, the 'online' array will have the
    same configuration set. If it is required to manipulate the array
    without affecting the online version, it is recommended to use the
    'offline' version. By specifying a different name, arbitrary amounts
    of arrays can be controlled at the same time.

    All operations on the array, such as loading a configuration
    or connecting amplifiers to stimulation units are done in
    software and no changes are applied to the hardware. Only once the
    :meth:`Array.download()` method is executed, the state of the array
    gets downloaded to the actual electrode array on the chip.

    Examples
    --------
    When creating configurations through the :meth:`Array.route()` method,
    all other configurations, such as connecting stimulation channels etc.
    will be lost. So the best procedure is to:

     1. Select electrodes
     2. Route
     3. Connect stimulation channels
     4. Save configuration

    >>> array = maxlab.chip.Array('online')
    >>> array.reset()
    >>> array.select_electrodes( [11110, 11111, 11112] )
    >>> array.select_stimulation_electrodes( [11330, 11331, 11332] )
    >>> array.route()
    >>> array.connect_electrode_to_stimulation( 11330 )
    >>> array.connect_electrode_to_stimulation( 11331 )
    >>> array.connect_electrode_to_stimulation( 11332 )
    >>> array.save_config("myConfig.cfg")
    >>>
    >>> stim1 = array.query_stimulation_at_electrode( 11330 )
    >>> stim2 = array.query_stimulation_at_electrode( 11331 )
    >>> stim3 = array.query_stimulation_at_electrode( 11332 )

    """

    def __init__(self, token: str = "online", persistent: bool = False) -> None:
        self.token = token
        self.persistent = persistent
        with comm.api_context() as api:
            api.send("mea_array_new " + self.token)

    def close(self) -> None:
        """Close this `Array` object.

        If `persistent` is not set, delete the array with the same token
        from the server.

        """
        if not self.persistent:
            with comm.api_context() as api:
                api.send("mea_array_delete " + self.token)

    def shutdown(self) -> None:
        self.close()

    def __send(self, command: str) -> str:
        with comm.api_context() as api:
            return api.send("mea_array_command " + self.token + "\n" + command)

    def reset(self) -> str:
        """Resets the array into a defined state.

        This method disconnects all electrodes and all amplifiers.

        Returns
        -------
        str
            Possible values are 'OK' or 'ERROR'

        """
        return self.__send("mea_array_reset")

    # Electrode selection & routing methods
    def select_stimulation_electrodes(self, electrodes: List[int]) -> str:
        """Select the given electrodes for stimulation.

        Parameters
        ----------
        electrodes : List[int]
            List of stimulation electrodes.

            The selected electrodes get automatically a high priority when
            routed.

        Returns
        -------
        str
            Possible values are 'OK' or 'ERROR'

        Notes
        -----
        Make sure not to select more than 1020 of these
        electrodes.  Otherwise, routing will not work (converge) well.

        """
        return self.select_electrodes(electrodes, 1000)

    def select_electrodes(self, electrodes: List[int], weight: int = 1) -> str:
        """Select the given electrodes for routing.

        Parameters
        ----------
        electrodes : List[int]
            List of recording electrodes.
        weight : int
            Set the routing priority for the electrodes.

            By passing a weight parameter, the routing priority for the
            electrodes can be adjusted.  The higher the weight, the higher
            the routing priority during routing.

            Only one weight can be set for the electrode ids in the method
            argument. Usually, different priorities need to be assigned and
            `select_electrodes` can be called for each set of priorities. See below
            for an example.

        Returns
        -------
        str
            Possible values are 'OK' or 'ERROR'

        Examples
        --------
        >>> array = maxlab.chip.Array()
        >>> array.select_electrodes([1,2,3,4], 10) # electrodes with priority of '10'
        >>> array.select_electrodes([5,6,7,8], 15) # other electrodes with a higher priority

        """
        return self.__send(
            "mea_array_select_electrodes " + " ".join([str(el) + "/" + str(weight) for el in electrodes])
        )

    def clear_selected_electrodes(self) -> str:
        """Clear all selected electrodes.

        Returns
        -------
        str
            Possible values are 'OK' or 'ERROR'

        """
        return self.__send("mea_array_clear_selected_electrodes")

    def route(self) -> str:
        """Route electrode configuration.

        Returns
        -------
        str
            Possible values are 'OK' or 'ERROR'

        Notes
        -----
        Be aware that any manual switch settings, such as stimulation
        connections, are lost after the routing. This is due to the
        routing starting from an 'empty' array.

        """
        return self.__send("mea_array_route")

    def load_config_data(self, config_file_data: str) -> str:
        return self.__send("mea_array_set_config " + config_file_data)

    def load_config(self, config_file_name: str) -> Union[str, int]:
        """Loads an electrode configuration from disk and sends it to the API.

        Parameters
        ----------
        config_file_name : str
            File name where to save the configuration to. Should end with ".cfg"

        Returns
        -------
        Union[str, int]
            If the configuration is successfully loaded and sent to the API, the
            method returns a string indicating either 'OK' or 'ERROR'.
            If there is an error or the configuration loading fails, the method
            returns an integer value of -1.

        """
        with open(config_file_name, "r") as config_file:
            config = config_file.read()
            return self.__send("mea_array_set_config " + config)
        return -1

    def save_config(self, config_file_name: str) -> int:
        """Save current array configuration to disk.

        Parameters
        ----------
        config_file_name : str
            File name where to save the configuration to. Should end with ".cfg"

        Returns
        -------
        int
            An integer value of 0 indicating the successful execution of the save operation.

        """
        with open(config_file_name, "w") as config_file:
            config = self.__send("mea_array_get_config")
            config_file.write(config)
        return 0

    def get_config(self) -> Config:
        """Obtain a :py:class:`mx.Config<maxlab.config.Config>` object representing the config routed to the Array.

        Returns
        -------
        Config
        """
        return Config(self.__send("mea_array_get_config"))

    def download(self, wells: Optional[List[int]] = None) -> None:
        """Download the electrode configuration to the chip.

        Parameters
        ----------
        wells : List[int]
            A list of the wells.

        """
        if wells is None:
            self.__send("mea_array_download")
        else:
            self.__send("mea_array_download_wells " + ",".join([str(w) for w in wells]))

    def set(self) -> str:
        return "mea_array_download"

    # Connect methods
    def connect_amplifier_to_stimulation(
        self, amplifier_channel: int
    ) -> str:  # chip.readoutToStim( self.getReadoutCh(stimBuffer) )
        """Connect the amplifier to a stimulation unit.

        Parameters
        ----------
        amplifier_channel : int
            Amplifier to be connected to a stimulation unit.

        Returns
        -------
        str
            Possible values are 'OK' or 'ERROR'

        """
        return self.__send("mea_array_connect_amplifier_to_stimulation " + str(amplifier_channel))

    def connect_amplifier_to_ringnode(self, amplifier_channel: int) -> str:
        """Connect amplifier to the common ring node.

        Parameters
        ----------
        amplifier_channel : int
            Amplifier to be connected to the ring node.

        Returns
        -------
        str
            Possible values are 'OK' or 'ERROR'

        Notes
        -----
        By enabling :meth:`Core.use_external_port()<maxlab.chip.Core.use_external_port()>`, the ring node
        can be connected to the external port.

        """
        return self.__send("mea_array_connect_amplifier_to_ringnode " + str(amplifier_channel))

    def connect_electrode_to_stimulation(self, electrode_no: int) -> str:
        """Connect electrode to stimulation unit.

        Parameters
        ----------
        electrode_no : int
            Electrode ID to be connected to a stimulation unit.

        Returns
        -------
        str
            Possible values are 'OK' or 'ERROR'

        Notes
        -----
        For this method to work, the selected electrode ID needs
        already be routed to an amplifier.

        """
        return self.__send("mea_array_connect_electrode_to_stimulation " + str(electrode_no))

    # Connect electrode to direct stimulation. Do not use this
    def connect_electrode_to_direct_stimulation(self, electrode_no: int) -> str:
        return self.__send("mea_array_connect_electrode_to_direct_stimulation " + str(electrode_no))

    def connect_all_floating_amplifiers(self) -> str:
        """Connect all floating amplifiers to a common node.

        Returns
        -------
        str
            Possible values are 'OK' or 'ERROR'

        Notes
        -----
        By enabling :meth:`Core.use_external_port()<maxlab.chip.Core.use_external_port()>`, the floating
        amplifiers can be connected to the external port.

        """
        return self.__send("mea_array_connect_all_floating_amplifiers")

    # Query methods
    def query_amplifier_at_stimulation(self, stimulation_channel: int) -> str:
        """Query amplifier at stimulation unit.

        Parameters
        ----------
        stimulation_channel : int
            Which stimulation unit to query.

        Returns
        -------
        str
            A string containing the number of the amplifier at the desired stimulation unit, or an empty string if no amplifier is connected.

        """
        return self.__send("mea_array_query_amplifier_at_stimulation " + str(stimulation_channel))

    def query_stimulation_at_amplifier(self, amplifier_channel: int) -> str:
        """Query stimulation unit at amplifier.

        Parameters
        ----------
        amplifier_channel : int
            Which amplifier channel to query.

        Returns
        -------
        str
            A string containing the number of the stimulation unit at the desired amplifier, or an empty string if no stimulation unit is connected.

        """
        return self.__send("mea_array_query_stimulation_at_amplifier " + str(amplifier_channel))

    def query_amplifier_at_electrode(self, electrode_no: int) -> str:
        """Query amplifier at the electrode.

        Parameters
        ----------
        electrode_no : int
            Which electrode ID to query.

        Returns
        -------
        str
            A string containing the number of the amplifier at the desired electrode, or an empty string if no amplifier is connected.

        """
        return self.__send("mea_array_query_amplifier_at_electrode " + str(electrode_no))

    def query_amplifier_at_ringnode(self) -> str:
        """Query which amplifiers are connected to the ring node.

        Returns
        -------
        str
            A string containing the number of the amplifier at the ring node, or an empty string if no amplifier is connected.

        """
        return self.__send("mea_array_query_amplifier_at_ringnode")

    def query_stimulation_at_electrode(self, electrode_no: int) -> str:
        """Query stimulation unit at the electrode.

        Parameters
        ----------
        electrode_no : int
            Which electrode ID to query.

        Returns
        -------
        str
            A string containing the number of the stimulation unit at the desired electrode, or an empty string if no stimulation unit is connected.

        """
        return self.__send("mea_array_query_stimulation_at_electrode " + str(electrode_no))

    # Disconnect methods
    def disconnect_amplifier_from_stimulation(self, amplifier_channel: int) -> str:
        """Disconnect amplifier from stimulation.

        Parameters
        ----------
        amplifier_channel : int
            Which amplifier channel to disconnect from a stimulation unit.

        Returns
        -------
        str
            Possible values are 'OK' or 'ERROR'

        """
        return self.__send("mea_array_disconnect_amplifier_from_stimulation " + str(amplifier_channel))

    def disconnect_electrode_from_stimulation(self, electrode: int) -> str:
        """Disconnect electrode from stimulation.

        Parameters
        ----------
        electrode : int
            Which electrode ID to disconnect from a stimulation unit.

        Returns
        -------
        str
            Possible values are 'OK' or 'ERROR'

        """
        return self.__send("mea_array_disconnect_electrode_from_stimulation " + str(electrode))

    def disconnect_amplifier_from_ringnode(self, amplifier_channel: int) -> str:
        """Disconnect amplifier from ring node.

        Parameters
        ----------
        amplifier_channel : int
            Which amplifier channel to disconnect from the ring node.

        Returns
        -------
        str
            Possible values are 'OK' or 'ERROR'

        """
        return self.__send("mea_array_disconnect_amplifier_from_ringnode " + str(amplifier_channel))

    # Aux methods
    def connect_all(self) -> str:
        return self.__send("mea_array_connect_all")

    def connect_electrode(self, electrode_no: int) -> str:
        return self.__send("mea_array_connect_electrode " + str(electrode_no))

    def disconnect_electrode(self, electrode_no: int) -> str:
        return self.__send("mea_array_disconnect_electrode " + str(electrode_no))


def power_down_all_stimulation_buffers() -> "StimulationUnit":
    return StimulationUnit(-1).power_up(False)
