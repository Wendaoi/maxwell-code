#!/usr/bin/python
# -*- coding: utf-8
import struct
from . import comm
from . import pycompat
from typing import List, Dict

__all__ = ["Stream"]


class Stream(object):
    @staticmethod
    def _deserialize(buffer: str) -> Dict[int, List[float]]:
        values: Dict[int, List[float]] = {}
        for line in buffer.split("\n##\n"):
            if ":" in line:
                well_str = line.split(":")[0]
                well = int(well_str)
                rest = line.split(":")[1]
                try:
                    values[well] = [float(x) for x in rest.split(",") if x != ""]
                except ValueError as e:
                    print("Error parsing stream data: " + str(e))
                    values[well] = []
        return values

    @staticmethod
    def start_demodulate(freq: int) -> None:
        with comm.api_context() as api:
            api.send("stream_set_demodulate " + str(freq))

    @staticmethod
    def stop_demodulate() -> None:
        with comm.api_context() as api:
            api.send("stream_set_demodulate 0")

    @staticmethod
    def get_amplitudes(wells: List[int]) -> Dict[int, List[float]]:
        with comm.api_context() as api:
            return Stream._deserialize(api.send("stream_get_amplitudes " + ",".join([str(w) for w in wells])))

    @staticmethod
    def get_mean() -> Dict[int, List[float]]:
        with comm.api_context() as api:
            return api.send("system_mean")
